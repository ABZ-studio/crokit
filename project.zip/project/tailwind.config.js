/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {
      colors: {
        bordeaux: {
          50: '#FBF0F1',
          100: '#F5DBDE',
          200: '#E8A8AE',
          300: '#D2727C',
          400: '#B0414E',
          500: '#8B2D3A',
          600: '#6B1F2A',
          700: '#561820',
          800: '#41131A',
          900: '#2D0D12',
          950: '#1A0709',
        },
        gold: {
          50: '#FBF6E9',
          100: '#F5EACB',
          200: '#EBD49A',
          300: '#DDBD63',
          400: '#C9A24B',
          500: '#B8862F',
          600: '#9A6E26',
          700: '#7A5620',
          800: '#5E421B',
          900: '#43301A',
        },
        cream: {
          50: '#FFFCF6',
          100: '#FAF3E7',
          200: '#F5EBD8',
          300: '#EDDCC0',
          400: '#E0C9A0',
          500: '#CFAF7A',
        },
        pistache: {
          300: '#B8D4A8',
          400: '#8BB27A',
          500: '#6E9A5C',
          600: '#557A47',
        },
        rose: {
          200: '#F0D5D5',
          300: '#E8C5C5',
          400: '#D9A0A0',
          500: '#C67E7E',
        },
      },
      fontFamily: {
        display: ['Anton', 'sans-serif'],
        accent: ['"Cormorant Garamond"', 'serif'],
        script: ['"Dancing Script"', 'cursive'],
        body: ['Manrope', 'sans-serif'],
      },
      letterSpacing: {
        tightest: '-0.04em',
        tighter: '-0.02em',
      },
      keyframes: {
        'ken-burns': {
          '0%': { transform: 'scale(1) translate(0, 0)' },
          '100%': { transform: 'scale(1.12) translate(-1.5%, -1%)' },
        },
        'shine': {
          '0%': { transform: 'translateX(-120%) skewX(-15deg)' },
          '100%': { transform: 'translateX(220%) skewX(-15deg)' },
        },
        'pulse-soft': {
          '0%, 100%': { opacity: '0.4', transform: 'translateY(0)' },
          '50%': { opacity: '1', transform: 'translateY(6px)' },
        },
      },
      animation: {
        'ken-burns': 'ken-burns 18s ease-out forwards',
        'shine': 'shine 1.2s ease-out',
        'pulse-soft': 'pulse-soft 2s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
