import { useSmoothScroll } from './hooks/useSmoothScroll';
import { Nav } from './components/Nav';
import { Hero } from './components/Hero';
import { VideoSpotlight } from './components/VideoSpotlight';
import { Story } from './components/Story';
import { Creations } from './components/Creations';
import { HowItWorks } from './components/HowItWorks';
import { ClientLove } from './components/ClientLove';
import { Location } from './components/Location';
import { Contact, Footer } from './components/Contact';

function App() {
  useSmoothScroll();

  return (
    <div className="min-h-screen bg-cream-100 text-bordeaux-900">
      <Nav />
      <main>
        <Hero />
        <VideoSpotlight />
        <Story />
        <Creations />
        <HowItWorks />
        <ClientLove />
        <Location />
        <Contact />
      </main>
      <Footer />
    </div>
  );
}

export default App;
