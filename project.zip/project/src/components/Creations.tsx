import { useState } from 'react';
import { motion } from 'framer-motion';
import { Instagram } from 'lucide-react';
import { Reveal } from './Reveal';

type Creation = {
  name: string;
  tag: string;
  img: string;
  desc: string;
};

const creations: Creation[] = [
  {
    name: 'Pastilla',
    tag: 'Signature',
    img: '/assets/images/WhatsApp_Image_2026-08-22_at_19.16.43.jpeg',
    desc: "Une délicieuse pastilla au poisson, croustillante à l'extérieur et généreusement garnie d'une savoureuse farce aux fruits de mer et aux épices.",
  },
  {
    name: 'Gauffres',
    tag: 'Liège',
    img: '/assets/images/k,.jpeg',
    desc: 'Une délicieuse gaufre de Liège, moelleuse et caramélisée à souhait, avec de généreux morceaux de sucre perlé.',
  },
  {
    name: 'Cookies américain',
    tag: 'Gourmand',
    img: '/assets/images/WhatsApp_Image_2026-08-22_at_19.08.27.jpeg',
    desc: "Un délicieux cookie américain, généreusement garni de chocolat, croustillant à l'extérieur et fondant à cœur.",
  },
  {
    name: 'Behla — gâteau beldi',
    tag: 'Fait maison',
    img: '/assets/images/kk.jpeg',
    desc: 'Un gâteau beldi moelleux, simple et savoureux, préparé selon la recette traditionnelle.',
  },
  {
    name: 'Cake fruits secs',
    tag: 'Gourmand',
    img: '/assets/images/WhatsApp_Image_2026-08-22_at_19.08.28.jpeg',
    desc: 'Un délicieux cake aux fruits secs, moelleux et savoureux, généreusement garni pour une touche gourmande et croquante.',
  },
  {
    name: 'Plateau gourmand',
    tag: 'À partager',
    img: '/assets/images/plateau.jpg',
    desc: 'Un assortiment généreux de douceurs façonnées à la main, pour les grandes tablées et les beaux moments.',
  },
  {
    name: 'Tartelettes',
    tag: 'Du jour',
    img: '/assets/images/99.jpg',
    desc: 'Petites tartes de saison, pâte sablée à la main et garnitures fraîches du jour.',
  },
  {
    name: 'cakes',
    tag: 'Signature',
    img: '/assets/images/88.jpg',

  },
  {
    name: 'cake fruits secs',
    tag: 'À partager',
    img: '/assets/images/999.jpg',
    desc: 'Sélection de gâteaux aux fruits secs, idéale pour les pauses thé et les grandes occasions.',
  },
];

export function Creations() {
  const [hovered, setHovered] = useState<number | null>(null);

  return (
    <section
      id="creations"
      className="relative overflow-hidden bg-cream-100 py-24 sm:py-32"
    >
      <div className="pointer-events-none absolute -left-24 top-24 h-48 w-48 rounded-full border border-gold-300/40" />

      {/* Section header */}
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <Reveal>
          <p className="font-accent text-base italic text-bordeaux-500">
            Lookbook
          </p>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-2 font-display text-5xl uppercase leading-[0.92] tracking-tightest text-bordeaux-800 sm:text-7xl">
            Quelques-unes de
            <br />
            <span className="text-gold-600">nos créations</span>
          </h2>
        </Reveal>
        <Reveal delay={0.1}>
          <p className="mt-5 max-w-lg text-base leading-relaxed text-bordeaux-900/70">
            Une sélection courte — pas un catalogue. Chaque pièce est façonnée
            à la main, en petite quantité, pour garder l'esprit artisanal.
          </p>
        </Reveal>
      </div>

      {/* Grid */}
      <div className="mx-auto mt-16 max-w-7xl px-6 sm:px-8">
        <div className="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
          {creations.map((c, i) => (
            <Reveal
              key={c.name}
              delay={(i % 3) * 0.08}
              scale={0.97}
              className="group relative overflow-hidden rounded-3xl bg-cream-50 shadow-sm ring-1 ring-bordeaux-900/5"
            >
              <div
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
                className="relative aspect-[4/5] cursor-pointer overflow-hidden rounded-3xl"
              >
                <img
                  src={c.img}
                  alt={c.name}
                  className="h-full w-full object-cover transition-transform duration-700 ease-out group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-bordeaux-950/85 via-bordeaux-950/10 to-transparent" />

                {/* tag */}
                <span className="absolute left-4 top-4 rounded-full bg-cream-50/95 px-3 py-1 text-[11px] font-semibold uppercase tracking-wider text-bordeaux-800 shadow-sm">
                  {c.tag}
                </span>

                {/* name + desc reveal */}
                <div className="absolute inset-x-0 bottom-0 p-5">
                  <motion.h3
                    animate={{ y: hovered === i ? 0 : 0 }}
                    className="font-display text-2xl uppercase text-cream-50"
                  >
                    {c.name}
                  </motion.h3>
                  <motion.p
                    initial={{ opacity: 0, height: 0 }}
                    animate={
                      hovered === i
                        ? { opacity: 1, height: 'auto' }
                        : { opacity: 0, height: 0 }
                    }
                    transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}
                    className="overflow-hidden text-sm leading-relaxed text-cream-200/90"
                  >
                    <span className="block pt-2">{c.desc}</span>
                  </motion.p>
                </div>

                {/* gold overlay on hover */}
                <div className="pointer-events-none absolute inset-0 bg-gold-400/0 transition-colors duration-500 group-hover:bg-gold-400/10" />
              </div>
            </Reveal>
          ))}
        </div>

        <Reveal delay={0.1} className="mt-12 flex justify-center">
          <a
            href="https://instagram.com/crok.it"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 rounded-full bg-bordeaux-700 px-6 py-3.5 text-sm font-semibold tracking-wide text-cream-50 transition-all duration-300 hover:bg-bordeaux-800 hover:shadow-lg hover:shadow-bordeaux-900/20"
          >
            <Instagram size={18} strokeWidth={2} />
            Voir plus sur notre Insta
          </a>
        </Reveal>
      </div>
    </section>
  );
}
