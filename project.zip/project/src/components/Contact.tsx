import { Reveal } from './Reveal';
import { ArrowUp, Instagram, MapPin, Music2, Youtube } from 'lucide-react';

const footerLinks = [
  { label: "L'atelier", href: '#histoire' },
  { label: 'Créations', href: '#creations' },
  { label: 'Sur commande', href: '#commande' },
  { label: 'Avis', href: '#avis' },
  { label: 'Localisation', href: '#localisation' },
];

const socials = [
  { label: 'Instagram', href: 'https://instagram.com/crok.it', Icon: Instagram },
  { label: 'TikTok', href: 'https://www.tiktok.com', Icon: Music2 },
  { label: 'YouTube', href: 'https://www.youtube.com/@latelier-crokit', Icon: Youtube },
];

export function Contact() {
  return (
    <section id="contact" className="relative bg-cream-100 py-24 sm:py-32">
      <div className="mx-auto grid max-w-7xl gap-12 px-6 sm:px-8 lg:grid-cols-[1fr_1fr] lg:gap-20">
        <div>
          <Reveal>
            <p className="font-accent text-lg italic text-bordeaux-500">Contact</p>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-2 font-display text-5xl uppercase leading-[0.95] tracking-tighter text-bordeaux-800 sm:text-6xl">
              Venez nous rencontrer
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-6 max-w-md text-lg leading-relaxed text-bordeaux-900/70">
              Pour déguster sur place, écrivez-nous en DM sur Instagram. On vous fixera un créneau dans l'atelier.
            </p>
          </Reveal>
          <Reveal delay={0.15}>
            <div className="mt-8 flex items-center gap-2.5 text-bordeaux-900/80">
              <MapPin size={20} className="text-bordeaux-500" strokeWidth={1.8} />
              <span>Casablanca, quartier Selouane, Maroc</span>
            </div>
          </Reveal>
        </div>

        <Reveal delay={0.1}>
          <div className="flex flex-col gap-3">
            <a
              href="https://instagram.com/crok.it"
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between rounded-2xl bg-bordeaux-700 px-6 py-5 text-cream-50 transition-all duration-300 hover:-translate-y-0.5 hover:bg-bordeaux-800 hover:shadow-xl hover:shadow-bordeaux-900/20"
            >
              <span className="flex items-center gap-3">
                <Instagram size={20} strokeWidth={1.8} />
                <span className="font-semibold">Écrire sur Instagram</span>
              </span>
              <span className="text-cream-200/70 transition-transform duration-300 group-hover:translate-x-1">@crok.it</span>
            </a>
            <a
              href="https://www.tiktok.com"
              target="_blank"
              rel="noopener noreferrer"
              className="group flex items-center justify-between rounded-2xl border border-bordeaux-900/15 bg-cream-50 px-6 py-5 text-bordeaux-800 transition-all duration-300 hover:-translate-y-0.5 hover:border-bordeaux-700 hover:shadow-lg hover:shadow-bordeaux-900/10"
            >
              <span className="flex items-center gap-3">
                <Music2 size={20} strokeWidth={1.8} />
                <span className="font-semibold">Suivre sur TikTok</span>
              </span>
              <span className="text-bordeaux-900/50 transition-transform duration-300 group-hover:translate-x-1">→</span>
            </a>
          </div>
        </Reveal>
      </div>
    </section>
  );
}

export function Footer() {
  return (
    <footer className="bg-bordeaux-900 text-cream-200">
      <div className="mx-auto max-w-7xl px-6 pb-10 pt-16 sm:px-8">
        <div className="grid gap-12 md:grid-cols-[1.2fr_1fr_1fr]">
          <Reveal>
            <img
              src="/assets/images/logo-removebg-preview.png"
              alt="Atelier Crok'it"
              className="h-24 w-auto object-contain drop-shadow-md"
            />
            <p className="mt-6 max-w-xs text-sm leading-relaxed text-cream-200/65">
              Pâtisserie artisanale faite maison, à Selouane, Casablanca.
            </p>
          </Reveal>

          <Reveal delay={0.08}>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-300">Navigation</p>
            <ul className="mt-5 space-y-3">
              {footerLinks.map((l) => (
                <li key={l.href}>
                  <a
                    href={l.href}
                    className="group inline-flex items-center gap-2 text-cream-100/80 transition-colors duration-300 hover:text-gold-200"
                  >
                    <span className="h-px w-0 bg-gold-300 transition-all duration-300 group-hover:w-4" />
                    {l.label}
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>

          <Reveal delay={0.16}>
            <p className="text-xs font-semibold uppercase tracking-[0.2em] text-gold-300">Suivez-nous</p>
            <ul className="mt-5 space-y-3">
              {socials.map(({ label, href, Icon }) => (
                <li key={label}>
                  <a
                    href={href}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group inline-flex items-center gap-3 text-cream-100/80 transition-colors duration-300 hover:text-gold-200"
                  >
                    <Icon size={18} strokeWidth={1.8} className="transition-transform duration-300 group-hover:-translate-y-0.5" />
                    {label}
                  </a>
                </li>
              ))}
            </ul>
          </Reveal>
        </div>

        <div className="mt-16 flex flex-col-reverse items-center justify-between gap-6 border-t border-cream-100/10 pt-8 sm:flex-row">
          <p className="text-sm text-cream-200/50">
            © {new Date().getFullYear()} Atelier Crok'it · Fait maison avec amour
          </p>
          <a
            href="#top"
            className="group inline-flex items-center gap-2 text-sm font-semibold text-cream-100/80 transition-colors hover:text-gold-200"
          >
            Retour en haut
            <span className="flex h-9 w-9 items-center justify-center rounded-full border border-cream-100/20 transition-all duration-300 group-hover:-translate-y-0.5 group-hover:border-gold-300 group-hover:bg-gold-300 group-hover:text-bordeaux-900">
              <ArrowUp size={16} />
            </span>
          </a>
        </div>
      </div>
    </footer>
  );
}
