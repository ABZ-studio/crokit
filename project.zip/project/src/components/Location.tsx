import { Reveal } from './Reveal';
import { MapPin, Navigation } from 'lucide-react';

const MAP_LINK =
  'https://www.google.com/maps/search/?api=1&query=Atelier%20Crok%E2%80%99it%2C33.548990127648686%2C-7.678189290225219';

export function Location() {
  return (
    <section
      id="localisation"
      className="relative overflow-hidden bg-bordeaux-800 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Text */}
          <div>
            <Reveal>
              <p className="font-accent text-base italic text-gold-300">
                Localisation
              </p>
            </Reveal>

            <Reveal delay={0.05}>
              <h2 className="mt-2 font-display text-5xl uppercase leading-[0.92] tracking-tightest text-cream-50 sm:text-6xl">
                Nous trouver à
                <br />
                <span className="text-gold-300">Selouane</span>
              </h2>
            </Reveal>

            <Reveal delay={0.1}>
              <p className="mt-6 max-w-md text-lg leading-relaxed text-cream-200/75">
                L'atelier est niché à Selouane, à Casablanca. Venez nous
                rendre visite pour déguster sur place autour d'un thé.
              </p>
            </Reveal>

            <Reveal delay={0.15}>
              <div className="mt-8 flex items-center gap-2.5 text-cream-100">
                <MapPin
                  size={20}
                  className="text-gold-300"
                  strokeWidth={1.8}
                />
                <span className="text-lg">
                  Casablanca, quartier Selouane — Maroc
                </span>
              </div>
            </Reveal>

            <Reveal delay={0.2}>
              <a
                href={MAP_LINK}
                target="_blank"
                rel="noopener noreferrer"
                className="group mt-6 inline-flex items-center gap-2.5 rounded-full border border-gold-300/60 bg-gold-300/10 px-6 py-3.5 text-sm font-semibold text-gold-200 transition-all duration-300 hover:bg-gold-300 hover:text-bordeaux-900"
              >
                <Navigation size={18} strokeWidth={2} />
                Ouvrir dans Google Maps
              </a>
            </Reveal>
          </div>

          <Reveal scale={0.96} className="order-first lg:order-last">
            <a
              href={MAP_LINK}
              target="_blank"
              rel="noopener noreferrer"
              aria-label="Ouvrir la localisation de l'Atelier Crok'it dans Google Maps"
              className="group block overflow-hidden rounded-3xl border border-gold-300/20 shadow-2xl shadow-bordeaux-950/50"
            >
              <img
                src="/assets/images/image.png"
                alt="Carte indiquant l'emplacement de l'Atelier Crok'it à Casablanca"
                className="h-auto w-full transition-transform duration-700 group-hover:scale-[1.02]"
              />
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}