import { useRef, useState } from 'react';
import { motion, useInView } from 'framer-motion';
import { Star, Quote, ArrowLeft, ArrowRight } from 'lucide-react';
import { CountUp } from './CountUp';
import { Reveal } from './Reveal';

const testimonials = [
  {
    text: "Un bel atelier proposant une sélection de la cuisine marocaine variée, notamment des pastillas, des briouats, et quelques types des gâteaux marocains.",
    author: 'Abdelfattah B.',
    role: 'Client fidèle',
  },
  {
    text: "Service magnifique, accueil avec sourire et comportement très professionnel. Je recommande !",
    author: 'Yasmine.',
    role: 'Cliente',
  },
  {
    text: "Des plats et gâteaux marocains et occidentaux faits maison, préparés avec soin et des produits de qualité. Je recommande",
    author: 'aymen',
    role: 'Client',
  },
  {
    text: "Franchement, rien à dire, travail au top ! 😍 Une qualité incroyable, beaucoup de sérieux et surtout un grand souci du détail. On voit que la personne aime ce qu’elle fait et ça se ressent dans le résultat. Je recommande à 100 %, continue comme ça ! 👏❤️",
    author: 'Abir o.',
    role: "Visiteuse de l'atelier",
  },
  {
    text: "Best in town.",
    author: 'meryem.',
    role: 'Cliente',
  },
];

export function ClientLove() {
  const [index, setIndex] = useState(0);
  const trackRef = useRef<HTMLDivElement>(null);
  const badgeRef = useRef<HTMLDivElement>(null);
  const badgeInView = useInView(badgeRef, { once: true, margin: '-15% 0px' });

  const scroll = (dir: 'left' | 'right') => {
    const track = trackRef.current;
    if (!track) return;
    const cardWidth = track.firstElementChild?.clientWidth ?? 320;
    const gap = 20;
    track.scrollBy({
      left: dir === 'left' ? -(cardWidth + gap) : cardWidth + gap,
      behavior: 'smooth',
    });
  };

  return (
    <section
      id="avis"
      className="relative overflow-hidden bg-bordeaux-950 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <Reveal>
          <p className="text-center font-accent text-base italic text-gold-300">
            Client Love
          </p>
        </Reveal>
        <Reveal delay={0.05}>
          <h2 className="mt-2 text-center font-display text-5xl uppercase leading-[0.92] tracking-tightest text-cream-50 sm:text-7xl">
            Ils en parlent
            <br />
            <span className="text-gold-300">mieux que nous</span>
          </h2>
        </Reveal>

        {/* 4.8 badge */}
        <div ref={badgeRef} className="mt-12 flex justify-center">
          <motion.div
            initial={{ opacity: 0, scale: 0.85 }}
            animate={badgeInView ? { opacity: 1, scale: 1 } : {}}
            transition={{ duration: 0.7, ease: [0.22, 1, 0.36, 1] }}
            className="relative overflow-hidden rounded-3xl border border-gold-300/30 bg-bordeaux-800 px-10 py-8 text-center shadow-2xl shadow-bordeaux-950/50"
          >
            <div className="relative flex items-center justify-center gap-1.5">
              {[0, 1, 2, 3, 4].map((i) => (
                <motion.span
                  key={i}
                  initial={{ scale: 0, rotate: -45 }}
                  animate={badgeInView ? { scale: 1, rotate: 0 } : {}}
                  transition={{
                    delay: 0.2 + i * 0.12,
                    duration: 0.4,
                    ease: [0.22, 1, 0.36, 1],
                  }}
                >
                  <Star
                    size={26}
                    className="fill-gold-300 text-gold-300"
                    strokeWidth={1}
                  />
                </motion.span>
              ))}
            </div>
            <div className="relative mt-3 font-display text-6xl text-cream-50">
              <CountUp to={4.7} decimals={1} duration={1.6} />
              <span className="text-gold-300"> / 5</span>
            </div>
            <p className="relative mt-2 text-sm font-medium tracking-wide text-cream-200/70">
              Note moyenne sur Google Maps
            </p>
          </motion.div>
        </div>

        {/* Carousel */}
        <div className="relative mt-16">
          <div
            ref={trackRef}
            className="flex snap-x snap-mandatory gap-5 overflow-x-auto scroll-smooth pb-6 [-ms-overflow-style:none] [scrollbar-width:none] [&::-webkit-scrollbar]:hidden"
          >
            {testimonials.map((t, i) => (
              <article
                key={i}
                className="w-[300px] flex-shrink-0 snap-center sm:w-[380px]"
              >
                <div className="flex h-full flex-col rounded-3xl border border-cream-100/10 bg-bordeaux-900/60 p-7 backdrop-blur-sm">
                  <Quote
                    size={32}
                    className="text-gold-400/60"
                    strokeWidth={1.5}
                  />
                  <p className="mt-4 flex-1 text-base leading-relaxed text-cream-100/90">
                    « {t.text} »
                  </p>
                  <div className="mt-6 flex items-center gap-3 border-t border-cream-100/10 pt-4">
                    <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-300/20 font-display text-lg text-gold-200">
                      {t.author.charAt(0)}
                    </div>
                    <div>
                      <p className="font-semibold text-cream-50">{t.author}</p>
                      <p className="text-xs text-cream-200/60">{t.role}</p>
                    </div>
                  </div>
                </div>
              </article>
            ))}
          </div>

          {/* Controls */}
          <div className="mt-6 flex items-center justify-between">
            <a
              href="https://www.google.com/search?q=latelier+crok+it&sxsrf=APpeQnulUSzPt1I0tWM8ww4xo35pETSQgA%3A1787420730112#lrd=0xda62d54ef035fcf:0x30bda31ec8211b4,3,,,,"
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm font-medium text-gold-200 underline-offset-4 hover:underline"
            >
              Laisser un avis sur Google Maps →
            </a>
            <div className="flex gap-2">
              <button
                onClick={() => scroll('left')}
                className="flex h-11 w-11 items-center justify-center rounded-full border border-cream-100/20 text-cream-100 transition-colors hover:bg-cream-50 hover:text-bordeaux-900"
                aria-label="Précédent"
              >
                <ArrowLeft size={18} />
              </button>
              <button
                onClick={() => scroll('right')}
                className="flex h-11 w-11 items-center justify-center rounded-full border border-cream-100/20 text-cream-100 transition-colors hover:bg-cream-50 hover:text-bordeaux-900"
                aria-label="Suivant"
              >
                <ArrowRight size={18} />
              </button>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
