import { Reveal, Stagger, StaggerItem } from './Reveal';
import { Instagram, MessageCircle, Coffee } from 'lucide-react';

const steps = [
  {
    icon: MessageCircle,
    title: 'En DM sur Instagram',
    desc: "Écrivez-nous directement sur @crok.it pour parler de votre envie, votre occasion, vos saveurs préférées. On répond à chaque message.",
  },
  {
    icon: Coffee,
    title: 'Sur place à l\'atelier',
    desc: "Venez déguster à Selouane, autour d'un thé. On vous reçoit dans la cuisine même où naissent les gâteaux — sur rendez-vous pris en DM.",
  },
  {
    icon: Instagram,
    title: 'Plateaux personnalisés',
    desc: "Mariage, baptême, fête, réception : on compose avec vous le plateau sucré ou salé qui correspond à votre événement.",
  },
];

export function HowItWorks() {
  return (
    <section
      id="commande"
      className="relative overflow-hidden bg-cream-100 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="max-w-2xl">
          <Reveal>
            <p className="font-accent text-base italic text-bordeaux-500">
              Sur commande & sur place
            </p>
          </Reveal>
          <Reveal delay={0.05}>
            <h2 className="mt-2 font-display text-5xl uppercase leading-[0.92] tracking-tightest text-bordeaux-800 sm:text-6xl">
              Comment ça
              <br />
              <span className="text-gold-600">se passe</span>
            </h2>
          </Reveal>
          <Reveal delay={0.1}>
            <p className="mt-5 text-lg leading-relaxed text-bordeaux-900/70">
              Pas de boutique en ligne, pas de panier, pas de tunnel de
              commande. Juste un échange, humain, et de vraies pâtisseries.
            </p>
          </Reveal>
        </div>

        <Reveal delay={0.12} className="mt-12">
          <div id="couscous" className="grid overflow-hidden rounded-3xl bg-bordeaux-700 sm:grid-cols-[0.9fr_1.1fr]">
            <div className="min-h-56 overflow-hidden sm:min-h-0">
              <img
                src="/assets/images/couscous.jpg"
                alt="Couscous préparé à l'atelier Crok'it"
                className="h-full w-full object-cover transition-transform duration-700 hover:scale-105"
              />
            </div>
            <div className="flex flex-col justify-center px-6 py-8 sm:px-10 sm:py-10">
              <p className="font-accent text-base italic text-gold-300">Le rendez-vous du vendredi</p>
              <h3 className="mt-2 font-display text-4xl uppercase leading-none text-cream-50 sm:text-5xl">
                Couscous chaque vendredi
              </h3>
              <p className="mt-4 max-w-lg text-base leading-relaxed text-cream-200/80">
                Chaque vendredi, l'atelier vous retrouve autour d'un couscous généreux, préparé avec le même soin que nos pâtisseries. Pensez à commander la veille.
              </p>
              <a
                href="https://instagram.com/crok.it"
                target="_blank"
                rel="noopener noreferrer"
                className="mt-6 w-fit text-sm font-semibold tracking-wide text-gold-200 underline decoration-gold-300/50 underline-offset-4 transition-colors hover:text-cream-50"
              >
                Commander la veille via Instagram →
              </a>
            </div>
          </div>
        </Reveal>

        <Stagger className="mt-14 grid gap-6 md:grid-cols-3" stagger={0.12}>
          {steps.map((s, i) => (
            <StaggerItem key={s.title}>
              <div className="group h-full rounded-3xl border border-bordeaux-200/50 bg-cream-50 p-8 shadow-sm transition-all duration-500 hover:-translate-y-1.5 hover:border-gold-300 hover:shadow-xl hover:shadow-bordeaux-900/10">
                <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-bordeaux-700 text-gold-200 transition-colors duration-500 group-hover:bg-gold-300 group-hover:text-bordeaux-800">
                  <s.icon size={26} strokeWidth={1.6} />
                </div>
                <p className="mt-5 font-display text-sm text-gold-600">
                  0{i + 1}
                </p>
                <h3 className="mt-1 font-display text-2xl uppercase leading-tight text-bordeaux-800">
                  {s.title}
                </h3>
                <p className="mt-3 text-base leading-relaxed text-bordeaux-900/65">
                  {s.desc}
                </p>
              </div>
            </StaggerItem>
          ))}
        </Stagger>

        <Reveal delay={0.1} className="mt-12">
          <a
            href="https://instagram.com/crok.it"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2.5 rounded-full bg-bordeaux-700 px-7 py-4 text-sm font-semibold tracking-wide text-cream-50 transition-all duration-300 hover:bg-bordeaux-800 hover:shadow-lg hover:shadow-bordeaux-900/30"
          >
            <Instagram size={18} strokeWidth={2} />
            Écrivez-nous en DM
          </a>
        </Reveal>
      </div>
    </section>
  );
}
