import { useRef } from 'react';
import { motion, useReducedMotion, useScroll, useTransform } from 'framer-motion';
import { ArrowDownRight, Instagram, ChevronDown } from 'lucide-react';

const productImages = [
  {
    src: '/assets/images/99.jpg',
    alt: 'Petites tartes aux fruits rouges de l’Atelier Crok’it',
  },
  {
    src: '/assets/images/88.jpg',
    alt: 'Gâteau artisanal à la pistache de l’Atelier Crok’it',
  },
  {
    src: '/assets/images/999.jpg',
    alt: 'Gâteaux aux fruits secs de l’Atelier Crok’it',
  },
];

const words = ['Fait', 'maison', 'avec', 'amour'];

const container = {
  hidden: {},
  visible: { transition: { staggerChildren: 0.12, delayChildren: 0.25 } },
};

const wordVar = {
  hidden: { opacity: 0, y: 32 },
  visible: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.7, ease: [0.22, 1, 0.36, 1] as const },
  },
};

const floatA = {
  animate: { y: [0, -10, 0], rotate: [-3, 2, -3] },
  transition: { duration: 7, repeat: Infinity, ease: 'easeInOut' as const },
};

const floatB = {
  animate: { y: [0, 9, 0], rotate: [4, -2, 4] },
  transition: { duration: 8, repeat: Infinity, ease: 'easeInOut' as const, delay: 0.6 },
};

const floatC = {
  animate: { y: [0, -7, 0], rotate: [-2, 3, -2] },
  transition: { duration: 6.5, repeat: Infinity, ease: 'easeInOut' as const, delay: 1.2 },
};

export function Hero() {
  const reduceMotion = useReducedMotion();
  const sectionRef = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: sectionRef,
    offset: ['start start', 'end start'],
  });
  const cookiesOpacity = useTransform(scrollYProgress, [0, 0.7], [1, 0]);
  const cookiesY = useTransform(scrollYProgress, [0, 0.7], [0, -60]);

  return (
    <section
      ref={sectionRef}
      id="top"
      className="relative overflow-hidden bg-cream-100 pt-28 sm:pt-32"
    >
      <div className="pointer-events-none absolute -right-32 top-32 h-72 w-72 rounded-full border border-gold-300/40 sm:h-96 sm:w-96" />
      <div className="pointer-events-none absolute bottom-16 left-8 h-3 w-3 rounded-full bg-gold-400 sm:left-16" />

      <div className="relative mx-auto grid min-h-[calc(100svh-7rem)] max-w-7xl items-center gap-12 px-6 pb-24 sm:px-8 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16 lg:pb-28">
        <div className="relative z-10 max-w-xl">
          <motion.p
            initial={{ opacity: 0, y: 12 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7 }}
            className="font-accent text-lg italic tracking-wide text-bordeaux-500 sm:text-xl"
          >
            Pâtisserie artisanale · Casablanca
          </motion.p>

          <motion.h1
            variants={container}
            initial="hidden"
            animate="visible"
            className="mt-4 font-display text-6xl uppercase leading-[0.9] tracking-tightest text-bordeaux-800 sm:text-8xl"
          >
            {words.map((word, index) => (
              <span key={word} className="mr-3 inline-block overflow-hidden last:mr-0">
                <motion.span variants={wordVar} className="inline-block">
                  {word}
                  {index === 1 && <span className="text-gold-500">.</span>}
                </motion.span>
              </span>
            ))}
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 18 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.8 }}
            className="mt-7 max-w-lg text-balance text-base leading-relaxed text-bordeaux-900/75 sm:text-lg"
          >
            Gâteaux Beldi, cookies fourrés et plateaux sucrés
            & salés. Tout est façonné à la main, dans notre atelier de Selouane.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 16 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.7, delay: 1 }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <a
              href="#creations"
              className="inline-flex items-center gap-2.5 rounded-full bg-bordeaux-700 px-6 py-3.5 text-sm font-semibold tracking-wide text-cream-50 transition-all duration-300 hover:bg-bordeaux-800 hover:shadow-lg hover:shadow-bordeaux-900/20"
            >
              Découvrir nos créations
              <ArrowDownRight size={18} strokeWidth={2} />
            </a>
            <a
              href="https://instagram.com/crok.it"
              target="_blank"
              rel="noopener noreferrer"
              className="inline-flex items-center gap-2.5 text-sm font-semibold tracking-wide text-bordeaux-700 transition-colors duration-300 hover:text-gold-600"
            >
              <Instagram size={18} strokeWidth={2} />
              @crok.it
            </a>
          </motion.div>
        </div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.9, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-2xl"
        >
          <div className="grid grid-cols-[1.15fr_0.85fr] gap-4 sm:gap-5">
            <div className="overflow-hidden rounded-[2rem] bg-cream-200 shadow-xl shadow-bordeaux-900/10">
              <img
                src={productImages[0].src}
                alt={productImages[0].alt}
                className="aspect-[4/5] h-full w-full object-cover transition-transform duration-700 hover:scale-105"
              />
            </div>
            <div className="grid gap-4 sm:gap-5">
              {productImages.slice(1).map((image) => (
                <div
                  key={image.src}
                  className="overflow-hidden rounded-[1.5rem] bg-cream-200 shadow-lg shadow-bordeaux-900/10"
                >
                  <img
                    src={image.src}
                    alt={image.alt}
                    className="aspect-[4/3] h-full w-full object-cover transition-transform duration-700 hover:scale-105"
                  />
                </div>
              ))}
            </div>
          </div>
          <div className="absolute -bottom-5 left-5 rounded-full border border-gold-400/60 bg-cream-50 px-4 py-2 text-xs font-semibold uppercase tracking-[0.18em] text-bordeaux-700 shadow-md sm:left-8">
            Petites séries · fait maison
          </div>
        </motion.div>
      </div>

      {/* Floating cookies — foreground layer, positioned to avoid text, fades out on scroll */}
      <motion.div
        style={{ opacity: cookiesOpacity, y: cookiesY }}
        className="pointer-events-none absolute inset-0 z-30 overflow-hidden"
      >
        <motion.img
          src="/assets/images/52be2178-14f9-4b92-ace9-9db074d7004c-removebg-preview.png"
          alt=""
          aria-hidden="true"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={
            reduceMotion
              ? { opacity: 1, scale: 1 }
              : { opacity: 1, scale: 1, ...floatA.animate }
          }
          transition={
            reduceMotion
              ? { duration: 0.8 }
              : { duration: 0.8, ...floatA.transition }
          }
          className="absolute -left-10 bottom-[4%] w-44 drop-shadow-[0_18px_30px_rgba(43,13,18,0.28)] sm:-left-16 sm:w-64 lg:-left-8 lg:bottom-[8%] lg:w-80"
        />
        <motion.img
          src="/assets/images/2fe545b6-b58c-4dc5-a434-c88dc29135d6-removebg-preview.png"
          alt=""
          aria-hidden="true"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={
            reduceMotion
              ? { opacity: 1, scale: 1 }
              : { opacity: 1, scale: 1, ...floatB.animate }
          }
          transition={
            reduceMotion
              ? { duration: 0.8, delay: 0.3 }
              : { duration: 0.8, delay: 0.3, ...floatB.transition }
          }
          className="absolute -right-10 bottom-[1%] w-44 drop-shadow-[0_18px_30px_rgba(43,13,18,0.28)] sm:-right-16 sm:w-64 lg:-right-8 lg:bottom-[2%] lg:w-80"
        />
        <motion.img
          src="/assets/images/52be2178-14f9-4b92-ace9-9db074d7004c-removebg-preview.png"
          alt=""
          aria-hidden="true"
          initial={{ opacity: 0, scale: 0.7 }}
          animate={
            reduceMotion
              ? { opacity: 1, scale: 1 }
              : { opacity: 1, scale: 1, ...floatC.animate }
          }
          transition={
            reduceMotion
              ? { duration: 0.8, delay: 0.5 }
              : { duration: 0.8, delay: 0.5, ...floatC.transition }
          }
          className="absolute right-[8%] top-[2%] w-36 drop-shadow-[0_18px_30px_rgba(43,13,18,0.25)] sm:w-52 lg:right-[12%] lg:top-[1%] lg:w-72"
        />
      </motion.div>

      <motion.a
        href="#histoire"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.5, duration: 0.8 }}
        className="absolute bottom-5 left-1/2 z-40 -translate-x-1/2 text-bordeaux-700/60"
        aria-label="Descendre"
      >
        <ChevronDown size={28} className="animate-pulse-soft" strokeWidth={1.5} />
      </motion.a>
    </section>
  );
}
