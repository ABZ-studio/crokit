import { useEffect, useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Instagram, Menu, X } from 'lucide-react';

const links = [
  { label: "L'atelier", href: '#histoire' },
  { label: 'Créations', href: '#creations' },
  { label: 'Sur commande', href: '#commande' },
  { label: 'Avis', href: '#avis' },
  { label: 'Localisation', href: '#localisation' },
  { label: 'Contact', href: '#contact' },
];

const INSTAGRAM_URL = 'https://instagram.com/crok.it';
const EASE = [0.22, 1, 0.36, 1] as const;

export function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    if (!open) return;
    const previousOverflow = document.body.style.overflow;
    document.body.style.overflow = 'hidden';
    const onKey = (e: KeyboardEvent) => {
      if (e.key === 'Escape') setOpen(false);
    };
    window.addEventListener('keydown', onKey);
    return () => {
      document.body.style.overflow = previousOverflow;
      window.removeEventListener('keydown', onKey);
    };
  }, [open]);

  const solid = scrolled || open;

  return (
    <>
      <motion.header
        initial={{ y: -96, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, ease: EASE }}
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ease-out ${
          solid
            ? 'bg-cream-50/95 shadow-[0_1px_0_rgba(45,13,18,0.08),0_8px_24px_-12px_rgba(45,13,18,0.18)] backdrop-blur-md'
            : 'bg-transparent'
        }`}
      >
        <nav className="mx-auto flex max-w-7xl items-center justify-between px-4 sm:px-8">
          <a
            href="#top"
            aria-label="Retour à l'accueil"
            onClick={() => setOpen(false)}
            className="group relative z-10 flex items-center py-2"
          >
            <motion.img
              src="/assets/images/logo-removebg-preview.png"
              alt="Atelier Crok'it"
              initial={{ opacity: 0, scale: 0.8, rotate: -6 }}
              animate={{ opacity: 1, scale: 1, rotate: 0 }}
              transition={{ delay: 0.2, duration: 0.8, ease: EASE }}
              className={`w-auto object-contain drop-shadow-sm transition-[height,transform] duration-500 ease-out group-hover:scale-105 group-hover:-rotate-3 ${
                solid ? 'h-10 sm:h-12' : 'h-12 sm:h-16'
              }`}
            />
          </a>

          <ul className="hidden items-center gap-1 rounded-full border border-bordeaux-900/10 bg-cream-50/80 p-1 shadow-sm backdrop-blur-sm lg:flex">
            {links.map((l) => (
              <li key={l.href}>
                <a
                  href={l.href}
                  className="block rounded-full px-4 py-2 text-sm font-medium text-bordeaux-800/80 transition-all duration-300 hover:bg-bordeaux-700 hover:text-cream-50"
                >
                  {l.label}
                </a>
              </li>
            ))}
          </ul>

          <div className="flex items-center gap-2">
            <a
              href={INSTAGRAM_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="hidden items-center gap-2 rounded-full bg-bordeaux-700 px-5 py-2.5 text-sm font-semibold text-cream-50 transition-all duration-300 hover:-translate-y-0.5 hover:bg-bordeaux-800 hover:shadow-lg hover:shadow-bordeaux-900/20 md:inline-flex"
            >
              <Instagram size={16} strokeWidth={2} />
              Suivre
            </a>

            <button
              type="button"
              onClick={() => setOpen((v) => !v)}
              className={`relative z-10 inline-flex h-11 items-center gap-2 rounded-full px-4 text-sm font-semibold transition-all duration-300 active:scale-95 lg:hidden ${
                open
                  ? 'bg-bordeaux-900/5 text-bordeaux-800'
                  : 'bg-bordeaux-700 text-cream-50 shadow-md shadow-bordeaux-900/15 hover:bg-bordeaux-800'
              }`}
              aria-label={open ? 'Fermer le menu' : 'Ouvrir le menu'}
              aria-expanded={open}
              aria-controls="mobile-menu"
            >
              <AnimatePresence initial={false} mode="wait">
                <motion.span
                  key={open ? 'close' : 'menu'}
                  initial={{ rotate: -90, opacity: 0 }}
                  animate={{ rotate: 0, opacity: 1 }}
                  exit={{ rotate: 90, opacity: 0 }}
                  transition={{ duration: 0.2 }}
                  className="flex"
                >
                  {open ? <X size={18} strokeWidth={2} /> : <Menu size={18} strokeWidth={2} />}
                </motion.span>
              </AnimatePresence>
              {open ? 'Fermer' : 'Menu'}
            </button>
          </div>
        </nav>
      </motion.header>

      <AnimatePresence>
        {open && (
          <>
            <motion.div
              key="mobile-backdrop"
              onClick={() => setOpen(false)}
              aria-hidden="true"
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.3 }}
              className="fixed inset-0 z-40 bg-bordeaux-950/50 backdrop-blur-sm lg:hidden"
            />
            <motion.aside
              key="mobile-menu"
              id="mobile-menu"
              initial={{ x: '100%' }}
              animate={{ x: 0 }}
              exit={{ x: '100%' }}
              transition={{ duration: 0.45, ease: EASE }}
              className="fixed inset-y-0 right-0 z-50 flex w-[min(88vw,22rem)] flex-col overflow-y-auto overscroll-contain bg-cream-50 px-6 pb-10 pt-24 shadow-2xl shadow-bordeaux-950/30 lg:hidden"
            >
              <p className="mb-4 text-xs font-semibold uppercase tracking-[0.2em] text-gold-600">Navigation</p>
              <ul>
                {links.map((l, i) => (
                  <motion.li
                    key={l.href}
                    initial={{ opacity: 0, x: 24 }}
                    animate={{ opacity: 1, x: 0 }}
                    exit={{ opacity: 0, transition: { duration: 0.1 } }}
                    transition={{ delay: 0.15 + i * 0.05, duration: 0.4, ease: EASE }}
                  >
                    <a
                      href={l.href}
                      onClick={() => setOpen(false)}
                      className="group flex items-center justify-between border-b border-bordeaux-900/10 py-5 font-display text-3xl uppercase tracking-tight text-bordeaux-800 transition-colors duration-300 active:text-gold-600 hover:text-gold-600"
                    >
                      {l.label}
                      <span className="h-px w-0 bg-gold-500 transition-all duration-300 group-hover:w-8" />
                    </a>
                  </motion.li>
                ))}
              </ul>

              <motion.a
                href={INSTAGRAM_URL}
                target="_blank"
                rel="noopener noreferrer"
                onClick={() => setOpen(false)}
                initial={{ opacity: 0, y: 16 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.5, duration: 0.45, ease: EASE }}
                className="mt-8 inline-flex w-fit items-center gap-2.5 rounded-full bg-bordeaux-700 px-6 py-3.5 text-sm font-semibold text-cream-50 transition-transform duration-300 active:scale-95"
              >
                <Instagram size={18} /> Suivre @crok.it
              </motion.a>
            </motion.aside>
          </>
        )}
      </AnimatePresence>
    </>
  );
}
