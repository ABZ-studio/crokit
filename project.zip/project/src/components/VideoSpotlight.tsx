import { Play, Youtube } from 'lucide-react';
import { Reveal } from './Reveal';

const VIDEO_POSTER = '/assets/images/998.jpg';
const YOUTUBE_VIDEO_URL = 'https://www.youtube.com/watch?v=PxIGATtJEkw';

export function VideoSpotlight() {
  return (
    <section id="video" className="relative overflow-hidden bg-bordeaux-800 py-20 sm:py-28">
      <div className="mx-auto grid max-w-7xl items-center gap-10 px-6 sm:px-8 lg:grid-cols-[1.1fr_0.9fr] lg:gap-16">
        <Reveal scale={0.97}>
          <a
            href={YOUTUBE_VIDEO_URL}
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Voir la vidéo de l'Atelier Crok'it sur YouTube"
            className="group relative block aspect-video overflow-hidden rounded-[2rem] border border-gold-300/30 bg-bordeaux-950 shadow-2xl shadow-bordeaux-950/40"
          >
            <img
              src={VIDEO_POSTER}
              alt="Miniature de la vidéo de l'Atelier Crok'it"
              className="h-full w-full object-cover transition-transform duration-500 group-hover:scale-105"
            />
            <div className="absolute inset-0 flex items-center justify-center bg-bordeaux-950/25 transition-colors group-hover:bg-bordeaux-950/40">
              <span className="flex h-16 w-16 items-center justify-center rounded-full bg-gold-300 text-bordeaux-900 shadow-lg transition-transform duration-300 group-hover:scale-110">
                <Play size={26} fill="currentColor" />
              </span>
            </div>
          </a>
        </Reveal>

        <div>
          <Reveal>
            <p className="font-accent text-base italic text-gold-300">
              Dans les coulisses
            </p>
          </Reveal>

          <Reveal delay={0.05}>
            <h2 className="mt-2 font-display text-5xl uppercase leading-[0.92] tracking-tightest text-cream-50 sm:text-6xl">
              Un peu de
              <br />
              <span className="text-gold-300">Crok'it</span>
            </h2>
          </Reveal>

          <Reveal delay={0.1}>
            <p className="mt-5 max-w-md text-lg leading-relaxed text-cream-200/75">
              Une minute pour voir les gestes, les textures et les douceurs qui
              prennent vie dans l'atelier.
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <a
              href="https://www.youtube.com/@latelier-crokit"
              target="_blank"
              rel="noopener noreferrer"
              className="mt-7 inline-flex items-center gap-2.5 rounded-full bg-gold-300 px-6 py-3.5 text-sm font-semibold text-bordeaux-900 transition-all duration-300 hover:bg-gold-200 hover:shadow-lg hover:shadow-bordeaux-950/30"
            >
              <Youtube size={19} strokeWidth={2} />
              S'abonner sur YouTube
            </a>
          </Reveal>
        </div>
      </div>
    </section>
  );
}