import { Reveal, Stagger, StaggerItem } from './Reveal';

const SHOP_IMG = '/assets/images/4.jpg';
const HANDS_IMG = '/assets/images/8.jpg';

const stats = [
  { value: '100%', label: 'Fait maison' },
  { value: '5+ ans', label: "D'amour dans la pâte" },
  { value: 'Selouane', label: 'Casablanca, Maroc' },
];

export function Story() {
  return (
    <section
      id="histoire"
      className="relative overflow-hidden bg-cream-100 py-24 sm:py-32"
    >
      <div className="mx-auto max-w-7xl px-6 sm:px-8">
        <div className="grid items-center gap-12 lg:grid-cols-2 lg:gap-16">
          {/* Images */}
          <div className="relative order-2 lg:order-1">
            <Reveal scale={0.95} className="overflow-hidden rounded-3xl shadow-2xl shadow-bordeaux-900/20">
              <img
                src={SHOP_IMG}
                alt="Devanture de l'atelier Crok'it"
                className="aspect-[4/3] w-full object-cover"
              />
            </Reveal>
            <Reveal
              delay={0.2}
              scale={0.95}
              className="absolute -bottom-10 -right-4 w-2/5 overflow-hidden rounded-2xl border-4 border-cream-100 shadow-xl sm:-right-8"
            >
              <img
                src={HANDS_IMG}
                alt="Présentoir de biscuits artisanaux dans l'atelier Crok'it"
                className="aspect-square w-full object-cover"
              />
            </Reveal>
            {/* decorative gold ring */}
            <div className="absolute -left-6 -top-6 -z-10 h-32 w-32 rounded-full border border-gold-300/40" />
          </div>

          {/* Text */}
          <div className="order-1 lg:order-2">
            <Reveal>
              <p className="font-accent text-base italic text-bordeaux-500">
                Notre histoire
              </p>
            </Reveal>
            <Reveal delay={0.05}>
              <h2 className="mt-2 font-display text-5xl uppercase leading-[0.92] tracking-tightest text-bordeaux-800 sm:text-6xl">
                L'atelier
                <br />
                <span className="text-gold-600">Crok'it</span>
              </h2>
            </Reveal>
            <Reveal delay={0.1}>
              <p className="mt-6 max-w-md text-lg leading-relaxed text-bordeaux-900/75">
                Niché à Selouane, à Casablanca, l'atelier Crok'it est un lieu
                où la pâtisserie se vit comme un geste lent et précis. Chaque
                gâteau, chaque plateau, est façonné à la main amandes
                effilées, pétales de rose, feuilles d'or, pistache dans le
                respect des recettes et des saveurs marocaines.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <p className="mt-4 max-w-md text-lg leading-relaxed text-bordeaux-900/75">
                Vous pouvez aussi venir déguster sur place, dans la chaleur de
                l'atelier, autour d'un thé .
              </p>
            </Reveal>

            <Stagger className="mt-10 grid grid-cols-3 gap-4" stagger={0.1}>
              {stats.map((s) => (
                <StaggerItem key={s.label}>
                  <div className="border-l-2 border-gold-400 pl-3">
                    <p className="font-display text-2xl uppercase text-bordeaux-700 sm:text-3xl">
                      {s.value}
                    </p>
                    <p className="mt-1 text-xs font-medium tracking-wide text-bordeaux-900/60">
                      {s.label}
                    </p>
                  </div>
                </StaggerItem>
              ))}
            </Stagger>
          </div>
        </div>
      </div>
    </section>
  );
}
